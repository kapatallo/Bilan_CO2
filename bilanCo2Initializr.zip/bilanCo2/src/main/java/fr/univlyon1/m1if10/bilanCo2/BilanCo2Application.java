package fr.univlyon1.m1if10.bilanCo2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BilanCo2Application {

	public static void main(String[] args) {
		SpringApplication.run(BilanCo2Application.class, args);
	}

}
