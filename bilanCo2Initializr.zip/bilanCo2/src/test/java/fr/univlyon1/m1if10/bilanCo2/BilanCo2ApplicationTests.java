package fr.univlyon1.m1if10.bilanCo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BilanCo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
